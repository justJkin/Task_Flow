package com.mycompany.taskflow.model;

public enum ProjectStatus {
    DRAFT, ACTIVE, ARCHIVED
}
