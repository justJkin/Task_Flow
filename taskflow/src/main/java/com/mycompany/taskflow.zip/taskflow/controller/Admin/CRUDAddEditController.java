package com.mycompany.taskflow.controller.Admin;

import com.mycompany.taskflow.model.DatabaseModel;
import com.mycompany.taskflow.model.Admin.User;
import com.mycompany.taskflow.model.Admin.Team;
import com.mycompany.taskflow.model.Admin.Project;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.mindrot.jbcrypt.BCrypt;

public class CRUDAddEditController {

    @FXML
    Label titleLabel;
    @FXML private VBox formContainer;

    // FXML Fields for User section (can be private now if only accessed via methods)
    @FXML private TextField firstNameTextField;
    @FXML private TextField lastNameTextField;
    @FXML private TextField emailTextField;
    @FXML private ComboBox<String> roleComboBox;
    @FXML private ComboBox<Integer> teamIdComboBox;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;


    // Map for dynamically created fields (Teams, Projects)
    Map<String, Control> fieldMap = new HashMap<>();

    String sectionName;
    private Object item; // Stores the object being edited (User, Team, Project) or null if adding
    private DataChangedListener dataChangedListener;

    // --- Setup Methods ---

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
        titleLabel.setText((item == null ? "Dodaj " : "Edytuj ") + sectionName);
        createFormFields(); // Assumes this method correctly sets up FXML fields or fieldMap
        populateFields();   // Assumes this method correctly populates fields from 'item'
    }

    public void setItem(Object item) {
        this.item = item;
        // No need to set currentUser separately if 'item' holds the User object
        if (sectionName != null) {
            populateFields();
        }
    }

    public void setOnDataChangedListener(DataChangedListener listener) {
        this.dataChangedListener = listener;
    }

    // --- GUI Form Creation/Population (Assumed to work, not the focus of refactoring) ---

    public void createFormFields() {
        formContainer.getChildren().clear();
        fieldMap.clear();

        // This method dynamically creates GUI controls based on sectionName
        // For "Użytkownicy", it likely configures the @FXML fields above.
        // For "Zespoły" and "Projekty", it adds controls to formContainer and fieldMap.
        // Implementation details are omitted for brevity, but crucial for the GUI to work.
        switch (sectionName) {
            case "Użytkownicy":
                // Assuming @FXML fields are part of the layout loaded by FXML Loader
                // If created dynamically, they need initialization here.
                addTextField("Imię", "firstName", firstNameTextField); // Example if dynamic
                addTextField("Nazwisko", "lastName", lastNameTextField);
                addTextField("Email", "email", emailTextField);
                addRoleComboBox("Rola", "role", roleComboBox);
                addTeamIdComboBox("Team ID", "teamId", teamIdComboBox);
                addPasswordField("Hasło", "password", passwordField);
                addPasswordField("Potwierdź hasło", "confirmPassword", confirmPasswordField);
                break;
            case "Zespoły":
                addTextField("Nazwa", "name"); // Adds to fieldMap
                break;
            case "Projekty":
                addTextField("Nazwa", "name"); // Adds to fieldMap
                addTextAreaField("Opis", "description"); // Adds to fieldMap
                addDatePicker("Data rozpoczęcia", "startDate"); // Adds to fieldMap
                addDatePicker("Data zakończenia", "endDate"); // Adds to fieldMap
                break;
        }
        System.out.println("Created fields for section: " + sectionName); // Debugging
    }

    // Helper methods for creating form fields dynamically (used by createFormFields)
    // Ensure these correctly initialize controls and add them to formContainer AND fieldMap if needed
    public void addDatePicker(String labelText, String fieldName) {
        Label label = new Label(labelText + ":");
        DatePicker datePicker = new DatePicker();
        HBox hbox = new HBox(10, label, datePicker);
        formContainer.getChildren().add(hbox);
        fieldMap.put(fieldName, datePicker); // Crucial for collectFormData
    }
    public void addPasswordField(String labelText, String fieldName, PasswordField field) {
        Label label = new Label(labelText + ":");
        // PasswordField field = new PasswordField(); // Only if field is not passed
        HBox hbox = new HBox(10, label, field);
        formContainer.getChildren().add(hbox);
        fieldMap.put(fieldName, field);
    }
    public void addRoleComboBox(String labelText, String fieldName, ComboBox<String> comboBox) {
        Label label = new Label(labelText + ":");
        try {
            List<String> roles = DatabaseModel.getRolesFromDatabase(); // Assume static method exists
            comboBox.getItems().setAll(roles); // Use setAll to clear previous items
        } catch (SQLException e) { /* handle appropriately */ }
        HBox hbox = new HBox(10, label, comboBox);
        formContainer.getChildren().add(hbox);
        fieldMap.put(fieldName, comboBox); // Also add ComboBox to map if needed elsewhere
    }
    public void addTextField(String labelText, String fieldName) { // For dynamic fields
        Label label = new Label(labelText + ":");
        TextField textField = new TextField();
        HBox hbox = new HBox(10, label, textField);
        formContainer.getChildren().add(hbox);
        fieldMap.put(fieldName, textField); // Crucial for collectFormData
    }
    public void addTextField(String labelText, String fieldName, TextField field) { // For @FXML fields
        Label label = new Label(labelText + ":");
        // TextField field = new TextField(); // Only if field is not passed
        HBox hbox = new HBox(10, label, field);
        formContainer.getChildren().add(hbox);
        fieldMap.put(fieldName, field); // Add FXML fields to map too for consistency? Or handle separately.
    }
    public void addTextAreaField(String labelText, String fieldName) {
        Label label = new Label(labelText + ":");
        TextArea textArea = new TextArea();
        HBox hbox = new HBox(10, label, textArea);
        formContainer.getChildren().add(hbox);
        fieldMap.put(fieldName, textArea); // Crucial for collectFormData
    }
    public void addTeamIdComboBox(String labelText, String fieldName, ComboBox<Integer> comboBox) {
        Label label = new Label(labelText + ":");
        try {
            List<Integer> teamIds = DatabaseModel.getTeamIdsFromDatabase(); // Assume static method exists
            comboBox.getItems().setAll(teamIds); // Use setAll
        } catch (SQLException e) { /* handle appropriately */ }
        HBox hbox = new HBox(10, label, comboBox);
        formContainer.getChildren().add(hbox);
        fieldMap.put(fieldName, comboBox);
    }

    public void populateFields() {
        // Populates GUI fields based on the 'item' being edited
        if (item != null) {
            switch (sectionName) {
                case "Użytkownicy":
                    User user = (User) item;
                    firstNameTextField.setText(user.getFirstName());
                    lastNameTextField.setText(user.getLastName());
                    emailTextField.setText(user.getEmail());
                    roleComboBox.setValue(user.getRole());
                    teamIdComboBox.setValue(user.getTeamId()); // Handles null automatically
                    // Password fields remain empty for editing
                    break;
                case "Zespoły":
                    Team team = (Team) item;
                    if (fieldMap.containsKey("name")) ((TextField) fieldMap.get("name")).setText(team.getName());
                    break;
                case "Projekty":
                    Project project = (Project) item;
                    if (fieldMap.containsKey("name")) ((TextField) fieldMap.get("name")).setText(project.getName());
                    if (fieldMap.containsKey("description")) ((TextArea) fieldMap.get("description")).setText(project.getDescription());
                    if (fieldMap.containsKey("startDate") && project.getStartDate() != null) ((DatePicker) fieldMap.get("startDate")).setValue(project.getStartDate().toLocalDate()); else if (fieldMap.containsKey("startDate")) ((DatePicker) fieldMap.get("startDate")).setValue(null);
                    if (fieldMap.containsKey("endDate") && project.getEndDate() != null) ((DatePicker) fieldMap.get("endDate")).setValue(project.getEndDate().toLocalDate()); else if (fieldMap.containsKey("endDate")) ((DatePicker) fieldMap.get("endDate")).setValue(null);
                    break;
            }
        } else {
            // Clear fields if adding new item (optional, could be handled by FXML)
            // e.g., firstNameTextField.clear(); ... etc.
        }
        System.out.println("Populated fields for section: " + sectionName); // Debugging
    }

    // --- Action Handlers ---

    @FXML
    public void handleSave() {
        try {
            // 1. Collect data from GUI controls
            Map<String, Object> formData = collectFormData();

            // 2. Perform validation and database logic (now separated)
            boolean success = performSaveLogic(formData, this.item);

            // 3. Handle UI feedback
            if (success) {
                closeWindow();
                notifyListener();
            }
        } catch (IllegalArgumentException e) { // Validation errors from performSaveLogic
            showAlert(Alert.AlertType.WARNING, e.getMessage());
        } catch (SQLException e) { // Database errors from performSaveLogic or DB methods
            e.printStackTrace(); // Log the full error
            showAlert(Alert.AlertType.ERROR, "Błąd bazy danych: " + e.getMessage());
        } catch (Exception e) { // Catch unexpected errors during data collection or logic
            e.printStackTrace(); // Log the full error
            showAlert(Alert.AlertType.ERROR,"Wystąpił nieoczekiwany błąd: " + e.getMessage());
        }
    }

    @FXML
    public void handleCancel() {
        closeWindow();
    }

    // --- Data Collection ---

    Map<String, Object> collectFormData() {
        Map<String, Object> data = new HashMap<>();
        System.out.println("Collecting data for section: " + sectionName); // Debugging
        switch (sectionName) {
            case "Użytkownicy":
                // Ensure FXML fields are initialized before calling getText/getValue
                if (firstNameTextField == null) throw new IllegalStateException("firstNameTextField not initialized!");
                data.put("firstName", firstNameTextField.getText());
                data.put("lastName", lastNameTextField.getText());
                data.put("email", emailTextField.getText());
                data.put("role", roleComboBox.getValue());
                data.put("teamId", teamIdComboBox.getValue()); // Can be null
                data.put("password", passwordField.getText());
                data.put("confirmPassword", confirmPasswordField.getText());
                break;
            case "Zespoły":
                if (!fieldMap.containsKey("name") || !(fieldMap.get("name") instanceof TextField)) throw new IllegalStateException("Team Name TextField not found in fieldMap!");
                data.put("name", ((TextField) fieldMap.get("name")).getText());
                break;
            case "Projekty":
                if (!fieldMap.containsKey("name") || !(fieldMap.get("name") instanceof TextField)) throw new IllegalStateException("Project Name TextField not found in fieldMap!");
                if (!fieldMap.containsKey("description") || !(fieldMap.get("description") instanceof TextArea)) throw new IllegalStateException("Project Description TextArea not found in fieldMap!");
                if (!fieldMap.containsKey("startDate") || !(fieldMap.get("startDate") instanceof DatePicker)) throw new IllegalStateException("Project StartDate DatePicker not found in fieldMap!");
                if (!fieldMap.containsKey("endDate") || !(fieldMap.get("endDate") instanceof DatePicker)) throw new IllegalStateException("Project EndDate DatePicker not found in fieldMap!");
                data.put("name", ((TextField) fieldMap.get("name")).getText());
                data.put("description", ((TextArea) fieldMap.get("description")).getText());
                data.put("startDate", ((DatePicker) fieldMap.get("startDate")).getValue()); // LocalDate or null
                data.put("endDate", ((DatePicker) fieldMap.get("endDate")).getValue());     // LocalDate or null
                break;
            default:
                throw new IllegalStateException("Unknown section name: " + sectionName);
        }
        System.out.println("Collected data: " + data); // Debugging
        return data;
    }

    // --- Core Logic Method (Testable) ---

    /**
     * Performs the core validation and save/update logic.
     * @param formData Map containing data collected from the form.
     * @param currentItem The object being edited (User, Team, Project), or null if adding.
     * @return true if the database operation was initiated successfully.
     * @throws SQLException If a database error occurs.
     * @throws IllegalArgumentException If validation fails (e.g., passwords don't match).
     */
    public boolean performSaveLogic(Map<String, Object> formData, Object currentItem) throws SQLException, IllegalArgumentException {
        switch (sectionName) {
            case "Użytkownicy":
                return handleUserSaveLogic(formData, currentItem);
            case "Zespoły":
                return handleTeamSaveLogic(formData, currentItem);
            case "Projekty":
                return handleProjectSaveLogic(formData, currentItem);
            default:
                throw new IllegalStateException("Unknown section name: " + sectionName);
        }
    }

    private boolean handleUserSaveLogic(Map<String, Object> formData, Object currentItem) throws SQLException, IllegalArgumentException {
        String password = (String) formData.get("password");
        String confirmPassword = (String) formData.get("confirmPassword");
        User originalUser = (currentItem instanceof User) ? (User) currentItem : null;

        // --- Password Validation ---
        if (originalUser == null && (password == null || password.isEmpty())) {
            throw new IllegalArgumentException("Hasło jest wymagane przy dodawaniu nowego użytkownika.");
        }
        if (password != null && !password.isEmpty() && !password.equals(confirmPassword)) {
            throw new IllegalArgumentException("Hasła nie pasują do siebie.");
        }

        // --- Prepare User Object ---
        User userToSave = new User();
        userToSave.setFirstName((String) formData.get("firstName"));
        userToSave.setLastName((String) formData.get("lastName"));
        userToSave.setEmail((String) formData.get("email"));
        userToSave.setRole((String) formData.get("role"));
        userToSave.setTeamId((Integer) formData.get("teamId")); // Allow null

        // --- Determine Password Hash ---
        String passwordHash = null;
        if (password != null && !password.isEmpty()) {
            passwordHash = BCrypt.hashpw(password, BCrypt.gensalt());
        } else if (originalUser != null) {
            passwordHash = originalUser.getPasswordHash(); // Keep old hash if not changing
        }
        // If originalUser is null and password was empty, validation above caught it.
        userToSave.setPasswordHash(passwordHash);


        // --- Database Operation ---
        if (originalUser == null) {
            insertUser(userToSave);
        } else {
            userToSave.setId(originalUser.getId()); // Set ID for update
            // Check if any actual changes were made before updating
            if (!userNeedsUpdate(userToSave, originalUser)) {
                System.out.println("No changes detected for user ID: " + originalUser.getId());
                return true; // No DB action needed, but operation considered "successful"
            }
            updateUser(userToSave); // Use a simpler update or the selective one
            // updateUserSelective(userToSave, originalUser); // Or use the selective version
        }
        return true;
    }

    private boolean userNeedsUpdate(User updated, User original) {
        if (original == null || updated == null) return true; // Should not happen here
        return !safeEquals(updated.getFirstName(), original.getFirstName()) ||
                !safeEquals(updated.getLastName(), original.getLastName()) ||
                !safeEquals(updated.getEmail(), original.getEmail()) ||
                !safeEquals(updated.getRole(), original.getRole()) ||
                !safeEquals(updated.getTeamId(), original.getTeamId()) || // Handles nulls
                !safeEquals(updated.getPasswordHash(), original.getPasswordHash());
    }
    // Helper for null-safe equals
    private boolean safeEquals(Object a, Object b) {
        return (a == b) || (a != null && a.equals(b));
    }


    private boolean handleTeamSaveLogic(Map<String, Object> formData, Object currentItem) throws SQLException {
        Team originalTeam = (currentItem instanceof Team) ? (Team) currentItem : null;
        String newName = (String) formData.get("name");

        // Basic validation
        if (newName == null || newName.trim().isEmpty()) {
            throw new IllegalArgumentException("Nazwa zespołu nie może być pusta.");
        }

        Team teamToSave = new Team();
        teamToSave.setName(newName.trim());

        if (originalTeam == null) {
            insertTeam(teamToSave);
        } else {
            // Only update if name actually changed
            if (!newName.trim().equals(originalTeam.getName())) {
                teamToSave.setId(originalTeam.getId());
                updateTeam(teamToSave);
            } else {
                System.out.println("No changes detected for team ID: " + originalTeam.getId());
            }
        }
        return true;
    }

    private boolean handleProjectSaveLogic(Map<String, Object> formData, Object currentItem) throws SQLException {
        Project originalProject = (currentItem instanceof Project) ? (Project) currentItem : null;

        String name = (String) formData.get("name");
        String description = (String) formData.get("description");
        LocalDate startDate = (LocalDate) formData.get("startDate");
        LocalDate endDate = (LocalDate) formData.get("endDate");

        // Basic Validation
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Nazwa projektu nie może być pusta.");
        }
        if (startDate != null && endDate != null && endDate.isBefore(startDate)) {
            throw new IllegalArgumentException("Data zakończenia nie może być wcześniejsza niż data rozpoczęcia.");
        }


        Project projectToSave = new Project();
        projectToSave.setName(name.trim());
        projectToSave.setDescription(description); // Allow empty description
        projectToSave.setStartDate(startDate != null ? Date.valueOf(startDate) : null);
        projectToSave.setEndDate(endDate != null ? Date.valueOf(endDate) : null);
        projectToSave.setAdminId(1); // Assuming a fixed admin ID for simplicity

        if (originalProject == null) {
            insertProject(projectToSave);
        } else {
            projectToSave.setId(originalProject.getId());
            // Check for changes before updating (optional but good practice)
            if (!projectNeedsUpdate(projectToSave, originalProject)) {
                System.out.println("No changes detected for project ID: " + originalProject.getId());
                return true; // No DB action needed
            }
            updateProject(projectToSave);
        }
        return true;
    }

    private boolean projectNeedsUpdate(Project updated, Project original) {
        if (original == null || updated == null) return true;
        // Compare relevant fields, handling nulls for dates
        return !safeEquals(updated.getName(), original.getName()) ||
                !safeEquals(updated.getDescription(), original.getDescription()) ||
                !safeEquals(updated.getStartDate(), original.getStartDate()) || // Date comparison works with equals
                !safeEquals(updated.getEndDate(), original.getEndDate());
    }


    // --- Database Interaction Methods (Now accept model objects) ---

    public void insertUser(User user) throws SQLException {
        String query = "INSERT INTO \"user\" (first_name, last_name, email, role, team_id, password_hash) VALUES (?, ?, ?, CAST(? AS role_enum), ?, ?)";
        try (Connection connection = DatabaseModel.connect();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, user.getFirstName());
            ps.setString(2, user.getLastName());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getRole());
            if (user.getTeamId() == null) {
                ps.setNull(5, java.sql.Types.INTEGER);
            } else {
                ps.setInt(5, user.getTeamId());
            }
            ps.setString(6, user.getPasswordHash());
            ps.executeUpdate();
        }
    }

    // Simplified update - updates all fields based on the passed object's ID
    public void updateUser(User user) throws SQLException {
        if (user.getId() <= 0) throw new IllegalArgumentException("User ID must be set for update.");
        String query = "UPDATE \"user\" SET first_name = ?, last_name = ?, email = ?, role = CAST(? AS role_enum), team_id = ?, password_hash = ? WHERE id = ?";
        try (Connection connection = DatabaseModel.connect();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, user.getFirstName());
            ps.setString(2, user.getLastName());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getRole());
            if (user.getTeamId() == null) {
                ps.setNull(5, java.sql.Types.INTEGER);
            } else {
                ps.setInt(5, user.getTeamId());
            }
            ps.setString(6, user.getPasswordHash());
            ps.setInt(7, user.getId());
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                System.err.println("WARN: Update User affected 0 rows for ID: " + user.getId());
                // Optionally throw exception if update must affect a row
            }
        }
    }

    // Optional: Keep the selective update logic if needed
    public void updateUserSelective(User updatedUser, User originalUser) throws SQLException {
        // (Implementation from previous refactoring example can go here if needed)
        // For simplicity, the non-selective updateUser is often sufficient if change detection happens before calling it.
        System.out.println("Warning: updateUserSelective called - consider using updateUser after change detection.");
        updateUser(updatedUser); // Delegate to simpler update for now
    }


    public void insertTeam(Team team) throws SQLException {
        String query = "INSERT INTO team (name) VALUES (?)";
        try (Connection connection = DatabaseModel.connect();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, team.getName());
            ps.executeUpdate();
        }
    }

    public void updateTeam(Team team) throws SQLException {
        if (team.getId() <= 0) throw new IllegalArgumentException("Team ID must be set for update.");
        String query = "UPDATE team SET name = ? WHERE id = ?";
        try (Connection connection = DatabaseModel.connect();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, team.getName());
            ps.setInt(2, team.getId());
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                System.err.println("WARN: Update Team affected 0 rows for ID: " + team.getId());
            }
        }
    }

    public void insertProject(Project project) throws SQLException {
        String query = "INSERT INTO project (name, description, start_date, end_date, admin_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseModel.connect();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, project.getName());
            ps.setString(2, project.getDescription());
            ps.setDate(3, project.getStartDate()); // Pass java.sql.Date directly
            ps.setDate(4, project.getEndDate());   // Pass java.sql.Date directly
            ps.setInt(5, project.getAdminId());
            ps.executeUpdate();
        }
    }

    public void updateProject(Project project) throws SQLException {
        if (project.getId() <= 0) throw new IllegalArgumentException("Project ID must be set for update.");
        String query = "UPDATE project SET name = ?, description = ?, start_date = ?, end_date = ? WHERE id = ?";
        try (Connection connection = DatabaseModel.connect();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, project.getName());
            ps.setString(2, project.getDescription());
            ps.setDate(3, project.getStartDate());
            ps.setDate(4, project.getEndDate());
            ps.setInt(5, project.getId());
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                System.err.println("WARN: Update Project affected 0 rows for ID: " + project.getId());
            }
        }
    }


    // --- UI Helpers ---

    void showAlert(Alert.AlertType type, String message) {
        // Check if running in Platform thread is needed, might be if called from non-FX thread
        // javafx.application.Platform.runLater(() -> {
        Alert alert = new Alert(type);
        alert.setTitle("Informacja");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
        // });
    }

    void closeWindow() {
        if (titleLabel != null && titleLabel.getScene() != null) {
            Stage stage = (Stage) titleLabel.getScene().getWindow();
            if (stage != null) {
                stage.close();
            }
        } else {
            System.err.println("WARN: Could not close window - titleLabel or scene not available.");
        }
    }

    void notifyListener() {
        if (dataChangedListener != null) {
            dataChangedListener.onDataChanged();
        }
    }

    // --- Listener Interface ---
    public interface DataChangedListener {
        void onDataChanged();
    }
}