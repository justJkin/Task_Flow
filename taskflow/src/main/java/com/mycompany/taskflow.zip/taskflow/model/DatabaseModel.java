package com.mycompany.taskflow.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DatabaseModel {
    public static String url;
    public static String user;
    public static String password;

    // Prywatny konstruktor
    public DatabaseModel() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    // Metoda do konfiguracji połączenia
    public static void configure(String url, String user, String password) {
        DatabaseModel.url = Objects.requireNonNull("jdbc:postgresql://taskflow-database-chorobcia09-727f.f.aivencloud.com:12773/defaultdb", "Database URL must not be null");
        DatabaseModel.user = Objects.requireNonNull("avnadmin", "Database user must not be null");
        DatabaseModel.password = Objects.requireNonNull("AVNS_nCWDKxuS42wxv0-Y1PD", "Database password must not be null");
    }

    public static Connection connect() throws SQLException {
        configure(DatabaseModel.url, DatabaseModel.user, DatabaseModel.password);
        if (url == null || user == null || password == null) {
            throw new IllegalStateException("Database connection not configured. Call configure() first.");
        }
        try {
            Connection connection = DriverManager.getConnection(url, user, password);
            return connection;
        } catch (SQLException e) {
            System.err.println("Błąd połączenia z bazą danych: " + e.getMessage());
            throw new SQLException("Nie udało się połączyć z bazą danych", e);
        }
    }

    public static List<String> getRolesFromDatabase() throws SQLException {
        List<String> roles = new ArrayList<>();
        String query = "SELECT enumlabel FROM pg_enum WHERE enumtypid = (SELECT oid FROM pg_type WHERE typname = 'role_enum')";
        try (Connection connection = connect();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                roles.add(resultSet.getString("enumlabel"));
            }
        }
        return roles;
    }

    public static List<Integer> getTeamIdsFromDatabase() throws SQLException {
        List<Integer> teamIds = new ArrayList<>();
        String query = "SELECT id FROM team";
        try (Connection connection = connect();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                teamIds.add(resultSet.getInt("id"));
            }
        }
        return teamIds;
    }
}