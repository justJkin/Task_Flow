package com.mycompany.taskflow.model;

public enum Role {
    ADMIN, MANAGER, USER
}
